# I LOVE MY NOTE — Android project

This Android Studio project wraps `app/src/main/assets/index.html` (the supplied `ILMN.HTML`) in an offline-capable WebView app. The supplied anime image is included as `app/src/main/res/drawable-nodpi/cover.png` and is also used as the Android launcher icon in the `mipmap-*` folders.

## Build APK in GitHub Actions
1. Upload the contents of this project to a GitHub repository, keeping the folder structure.
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Open **Build Android APK** and click **Run workflow** (or push a commit to `main`/`master`).
4. When the run finishes successfully, open the run and download **ILMN-debug-APK** under **Artifacts**.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow builds a debug APK. It is suitable for testing and manual installation, but it is not a Play Store-signed release.

## Build APK in Android Studio
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The generated APK is typically at `app/build/outputs/apk/debug/app-debug.apk`.

Notes are stored using the page's browser local storage. Uninstalling the app may remove local notes; export/backup them first if the page offers that option.
